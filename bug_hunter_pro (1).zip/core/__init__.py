# Core logic and entry point
