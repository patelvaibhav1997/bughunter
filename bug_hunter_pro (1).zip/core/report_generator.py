# Will handle report formatting (HTML, Markdown, etc.)
