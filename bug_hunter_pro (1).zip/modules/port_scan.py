# Port scanning logic using nmap
