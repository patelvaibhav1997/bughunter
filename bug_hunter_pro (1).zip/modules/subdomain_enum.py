# Subdomain enumeration logic
