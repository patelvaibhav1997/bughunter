# For API-specific testing like auth bypass or rate-limit
