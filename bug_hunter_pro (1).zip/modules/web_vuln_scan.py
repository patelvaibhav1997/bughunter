# Wrapper for tools like nikto or nuclei
